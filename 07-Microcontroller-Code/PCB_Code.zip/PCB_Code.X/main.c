#include "mcc_generated_files/system/system.h"
#include <builtins.h>
#include <stdio.h>

// --- Dummy ADC ISR handlers to satisfy the linker ---
void ADC_ISR(void)
{
    // Do nothing
}

void ADC_ThresholdISR(void)
{
    // Do nothing
}
// ----------------------------------------------------

/*
 main application
 */

int main(void)
{
    SYSTEM_Initialize();
    ADC_Initialize();
    UART1_Initialize();
    
    int result;
    
    ADC_ChannelSelect(ADC_CHANNEL_ANA2);
    
    for(uint8_t i = 0; i < 3; i++)
    {
        IO_RB0_SetHigh();
        __delay_ms(200);
        IO_RB0_SetLow();
        __delay_ms(200);
    }
    
    while(1)
    {
        ADC_ConversionStart();
        result = ADC_ConversionResultGet();
        
        printf("Photoresistor Value = %d \r\n", result);
        
        if(result >= 3700)
        {
            IO_RB0_SetHigh();
            __delay_ms(100);
        }
        
        if(result < 3700)
        {
            IO_RB0_SetLow();
            __delay_ms(100);
        }
    }
    return 0;
}
